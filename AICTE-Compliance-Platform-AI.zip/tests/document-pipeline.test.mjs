import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {deflateSync} from 'node:zlib';
import {extractPdfText} from '../src/pdf-text.mjs';
import {processDocument,compareExtraction,documentSchemas} from '../src/document-pipeline.mjs';

test('PDF text parser extracts Tj, TJ and Flate streams',()=>{
 const plain=Buffer.from('%PDF-1.4\n<< /Length 90 >>\nstream\nBT (Institution Name: Northstar College) Tj [(Registration No: ABC-123)] TJ ET\nendstream\n%%EOF','latin1');
 const extracted=extractPdfText(plain);assert.match(extracted.text,/Institution Name: Northstar College/);assert.match(extracted.text,/Registration No: ABC-123/);assert.equal(extracted.pageReferences,false);
 const compressed=deflateSync(Buffer.from('BT (Faculty Name: Ada Example) Tj ET','latin1'));
 const flate=Buffer.concat([Buffer.from('<< /Filter /FlateDecode >>\nstream\n','latin1'),compressed,Buffer.from('\nendstream','latin1')]);assert.match(extractPdfText(flate).text,/Faculty Name: Ada Example/);
});
test('document pipeline extracts only labeled fields and flags possible institution mismatch',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'aicte-pipeline-'));try{const file=path.join(dir,'sample.pdf');await writeFile(file,Buffer.from('%PDF-1.4\nBT (Institution Name: Different College; Registration No: REG-7788) Tj ET\n%%EOF'));const result=await processDocument({filePath:file,mime:'application/pdf',category:'R-DEMO-01',app:{institution:'Expected College'}});assert.equal(result.status,'completed_deterministic');assert.equal(result.fields.registrationNumber.value,'REG-7788');assert.equal(result.fields.unknownField,undefined);assert.equal(result.consistency[0].kind,'potential_inconsistency');assert.equal(result.fields.institutionName.source,'local_label_pattern')}finally{await rm(dir,{recursive:true,force:true})}
});
test('scan-only PDF is routed to manual OCR instead of being called complete',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'aicte-scan-'));try{const file=path.join(dir,'scan.pdf');await writeFile(file,'%PDF-1.4\n%image-only scan');const result=await processDocument({filePath:file,mime:'application/pdf',category:'R-DEMO-02',app:{institution:'College'}});assert.equal(result.status,'needs_manual_ocr');assert.equal(result.fields.personName,undefined);assert.match(result.message,/No native PDF text/)}finally{await rm(dir,{recursive:true,force:true})}
});
test('schema definitions are document-specific and extracted field changes are detectable',()=>{
 assert.ok(documentSchemas['R-DEMO-02'].fields.includes('qualification'));assert.ok(!documentSchemas['R-DEMO-01'].fields.includes('qualification'));const old=JSON.stringify({certificateNumber:{value:'OLD'}});const changes=compareExtraction(old,{certificateNumber:{value:'NEW'}});assert.deepEqual(changes,[{field:'certificateNumber',previous:'OLD',current:'NEW',source:'extracted_value_comparison'}]);
});
