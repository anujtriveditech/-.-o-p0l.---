import test from 'node:test';
import assert from 'node:assert/strict';
import { writeFile, mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { parseDocDate, runComplianceChecks } from '../src/compliance-check.mjs';
import { loadRuleset } from '../src/rules.mjs';
import { normalizeExtraction } from '../src/ai-extractor.mjs';
import { parseJsonObject, aiConfig } from '../src/ai-provider.mjs';

const ruleset = loadRuleset();
const doc = (id, category, fields, extra = {}) => ({ id, name: id + '.pdf', category, version: 1, sha: id, processing_status: 'completed_deterministic', extracted_json: JSON.stringify(Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, { value: v }]))), ...extra });

test('dates are only parsed when unambiguous', () => {
  assert.equal(parseDocDate('2026-03-31').toISOString().slice(0, 10), '2026-03-31');
  assert.equal(parseDocDate('31/03/2026').toISOString().slice(0, 10), '2026-03-31');
  assert.equal(parseDocDate('03/04/2026'), null); assert.equal(parseDocDate('31/02/2026'), null); assert.equal(parseDocDate('soon'), null);
});
test('ruleset is versioned, unverified by default, and "verified" needs a source and effective date', async () => {
  assert.equal(ruleset.verified, false); assert.equal(ruleset.status, 'illustrative_unverified'); assert.ok(ruleset.version);
  const f = path.join(await mkdtemp(path.join(tmpdir(), 'rules-')), 'r.json');
  await writeFile(f, JSON.stringify({ version: '1', rules: [{ id: 'A', label: 'A', verified: true }, { id: 'B', label: 'B', verified: true, source: 'Handbook cl. 1', effectiveFrom: '2026-01-01' }] }));
  const r = loadRuleset(f); assert.equal(r.rules[0].verified, false); assert.equal(r.rules[1].verified, true); assert.equal(r.warnings.length, 1); assert.equal(r.status, 'illustrative_unverified');
});
test('deterministic checks find gaps, mismatches, duplicates and date problems with evidence', () => {
  const app = { institution: 'Northstar College' };
  const docs = [
    doc('d1', 'R-DEMO-01', { institutionName: 'Northstar College', issueDate: '2026-05-01', validityDate: '2026-01-01' }, { sha: 'same' }),
    doc('d2', 'R-DEMO-03', { institutionName: 'Southstar College' }, { sha: 'same' }),
    doc('d3', 'R-DEMO-02', {}, { processing_status: 'needs_manual_ocr' })
  ];
  const checks = runComplianceChecks({ app, documents: docs, ruleset, now: new Date('2026-10-25T00:00:00Z') });
  const kinds = checks.map(c => c.kind);
  for (const k of ['date_order', 'validity_date_passed', 'institution_name_mismatch', 'cross_document_name_mismatch', 'duplicate_upload', 'unreadable_document']) assert.ok(kinds.includes(k), k);
  assert.ok(!kinds.includes('missing_document'));
  const dup = checks.find(c => c.kind === 'duplicate_upload'); assert.equal(dup.evidence.length, 2);
  assert.ok(checks.every(c => c.evidence.length > 0 && c.explanation && c.recommendation));
  assert.ok(checks.filter(c => c.ruleId).every(c => c.ruleVerified === false));
  assert.ok(!checks.some(c => /fraud|forg/i.test(c.explanation)));
});
test('only the latest version per checklist item is checked', () => {
  const docs = [doc('old', 'R-DEMO-01', { institutionName: 'Wrong' }), { ...doc('new', 'R-DEMO-01', { institutionName: 'Northstar College' }), version: 2 }];
  const checks = runComplianceChecks({ app: { institution: 'Northstar College' }, documents: docs, ruleset });
  assert.ok(!checks.some(c => c.kind === 'institution_name_mismatch'));
});
test('model output normalisation drops unsupported, unquoted and off-schema values', () => {
  const text = 'Registration Number: ABC-1 issued by Council X';
  const n = normalizeExtraction({ fields: { registrationNumber: { value: 'ABC-1', evidence_quote: 'Registration Number: ABC-1' }, issuingAuthority: { value: 'Council Y', evidence_quote: 'issued by Council X' }, issueDate: { value: '2020-01-01' }, hack: { value: 'x', evidence_quote: 'x' } }, issues: [{ type: 'unreadable', field: 'hack', detail: 'd', evidence_quote: 'nope' }] }, ['registrationNumber', 'issuingAuthority', 'issueDate'], text);
  assert.deepEqual(Object.keys(n.fields), ['registrationNumber']); assert.equal(n.dropped.length, 2); assert.equal(n.issues[0].field, null); assert.equal(n.issues[0].quoteVerified, false);
});
test('JSON replies are parsed from fenced or chatty output; config requires explicit values', () => {
  assert.deepEqual(parseJsonObject('```json\n{"a":1}\n```'), { a: 1 }); assert.deepEqual(parseJsonObject('Sure! {"a":2} done'), { a: 2 });
  assert.throws(() => parseJsonObject('no json'), e => e.code === 'bad_output');
  assert.equal(aiConfig({}).configured, false); assert.equal(aiConfig({ AICTE_AI_PROVIDER: 'anthropic', ANTHROPIC_API_KEY: 'k' }).configured, false);
  assert.equal(aiConfig({ AICTE_AI_PROVIDER: 'claude', ANTHROPIC_API_KEY: 'k', AICTE_AI_MODEL: 'm' }).configured, true);
  assert.equal(aiConfig({ AICTE_AI_BASE_URL: 'http://x', AICTE_AI_API_KEY: 'k', AICTE_AI_MODEL: 'm' }).provider, 'openai-compatible'); // legacy variables still work
});
