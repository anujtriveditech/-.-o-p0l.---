# AICTE Approval and Compliance — local demonstration

A local, synthetic-data application workflow with an asynchronous document assistance pipeline. It is not an AICTE service and makes no official regulatory decisions. Checklist items are placeholders, not verified AICTE requirements.

## Run

Requires Node.js 24+. From this directory:

```powershell
node --experimental-sqlite server.mjs
```

Open http://localhost:4173. Demo sign-ins (public credentials): `institution@example.test` or `evaluator@example.test`, or `decision-maker@example.test`; password `Demo1234!`.

Institution users can create drafts, upload documents, submit, read findings and resubmit corrections. Evaluators receive a prioritized queue and can return a case or record a recommendation. A separate decision-maker account can approve, reject, or return recommended cases with a required written reason. Each outcome is recorded in the workflow history and has a downloadable demonstration decision record clearly labeled as non-official. Records persist in `work/demo.sqlite` and bytes in `work/uploads`.

## Document automation

Every accepted PDF/JPEG/PNG upload creates a document record and job. The local pipeline validates the upload, stores a SHA-256, assigns the selected checklist category to a category-specific document schema, extracts text from uncompressed and Flate-compressed PDF text streams, applies explicit-label field patterns, compares an extracted institution name with the application, detects repeated file hashes, compares extracted fields across document versions, saves findings, and creates in-app notifications. Processing jobs resume queued/in-progress records at server startup and can be retried up to three attempts.

Processing details are shown under each uploaded file. The preliminary JSON report is available from the application detail panel and `GET /api/applications/{id}/report`. Other support endpoints include `GET /api/jobs`, `GET /api/notifications`, `GET /api/review-queue` (evaluator only), `GET /api/decision-queue` (decision maker only), `POST /api/applications/{id}/decision`, `GET /api/applications/{id}/decision-document`, and `GET /api/ai/status`.

### Actual, optional integrations

- **Native PDF parsing:** local deterministic text-operator parsing. It does not handle every PDF encoding, encrypted PDF, complex font map, or resolve page references.
- **OCR:** not installed in this environment. For JPEG/PNG, set `AICTE_TESSERACT_PATH` to a trusted Tesseract executable; optionally set `AICTE_OCR_LANGUAGE`. Scanned PDFs still need a trusted PDF-to-image renderer and OCR stage; until configured they are routed for manual OCR.
- **Configured model:** no model call occurs by default. To enable the optional OpenAI-compatible extraction adapter, set `AICTE_AI_BASE_URL`, `AICTE_AI_API_KEY`, and `AICTE_AI_MODEL`. Text is sent to that configured endpoint, so configure only an approved provider and account. Outputs are marked as AI suggestions with human review required; credentials are never shown by the UI.
- **Rules:** official handbook sources and clauses are not configured. The checklist and categories are demonstration placeholders.

Deterministic extraction, optional OCR, and model suggestions are labeled separately. Confidence values are not presented as calibrated. No extraction proves authenticity, no discrepancy is classified as fraud, and no AI output can approve/reject an application.

## Tests

```powershell
node --test
```

Thirteen tests cover PDF parsing, field schemas, consistency flags, scan routing, extraction changes, sign-in/RBAC, workflow transitions, file upload/download, report/queue endpoints, processing notifications, and authorized human final decisions. Tests use temporary SQLite and upload directories.

## Limits

This is a local prototype with public demo credentials, in-memory sessions, no malware scanning, no production-grade identity or storage encryption, no official regulatory data, no deadlines, no SMS/email integration, no physical inspection workflow, and no independently anchored audit log. Do not expose it to a network or upload real records. See `docs/automation.md`, `docs/regulatory-assumptions.md`, and `docs/security-operations.md`.






## AI features (optional)
AI document analysis, plain-English finding explanations, reviewer summaries / institution correction guidance and a Q&A assistant are built in but off until you configure a provider. Copy `.env.example` to `.env`, choose Anthropic Claude or an OpenAI-compatible endpoint, add your own API key and model, and restart. See `docs/ai-integration.md` for setup, data-protection notes (external providers receive the data sent to them), cost controls and limits. AI is advisory only and never approves, rejects or decides.
