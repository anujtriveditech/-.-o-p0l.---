// Server-side AI provider layer. All model calls in the application go through callModel().
// Supported providers:
//   anthropic          Anthropic Claude via the official Messages API (https://api.anthropic.com/v1/messages)
//   openai-compatible  Any OpenAI-compatible /chat/completions endpoint (kept from the original MVP)
// Configuration is read from environment variables at call time. Keys are never returned, logged or
// included in error messages.

const ANTHROPIC_VERSION = '2023-06-01';
const DEFAULT_ANTHROPIC_BASE = 'https://api.anthropic.com';

export class AIError extends Error {
  constructor(code, message, status = 502) { super(message); this.name = 'AIError'; this.code = code; this.status = status; }
}

const clamp = (v, d, min, max) => { const n = Number(v); return Number.isFinite(n) && v !== '' && v != null ? Math.min(max, Math.max(min, n)) : d; };
const flag = v => ['1', 'true', 'yes', 'on'].includes(String(v || '').trim().toLowerCase());

export function aiConfig(env = process.env) {
  const raw = (env.AICTE_AI_PROVIDER || '').trim().toLowerCase();
  const aliases = { claude: 'anthropic', anthropic: 'anthropic', openai: 'openai-compatible', 'openai-compatible': 'openai-compatible' };
  let provider = raw ? aliases[raw] : (env.AICTE_AI_BASE_URL ? 'openai-compatible' : (env.ANTHROPIC_API_KEY ? 'anthropic' : ''));
  const missing = [];
  let key = '', baseUrl = '', model = (env.AICTE_AI_MODEL || (provider === 'anthropic' ? env.ANTHROPIC_MODEL : '') || '').trim();
  let problem = null;
  if (raw && !provider) problem = `Unknown AICTE_AI_PROVIDER "${raw.slice(0, 40)}". Use "anthropic" or "openai-compatible".`;
  if (provider === 'anthropic') {
    key = env.ANTHROPIC_API_KEY || env.AICTE_AI_API_KEY || '';
    baseUrl = (env.AICTE_ANTHROPIC_BASE_URL || DEFAULT_ANTHROPIC_BASE).replace(/\/$/, '');
    if (!key) missing.push('ANTHROPIC_API_KEY');
    if (!model) missing.push('AICTE_AI_MODEL');
  } else if (provider === 'openai-compatible') {
    key = env.AICTE_AI_API_KEY || '';
    baseUrl = (env.AICTE_AI_BASE_URL || '').replace(/\/$/, '');
    if (!baseUrl) missing.push('AICTE_AI_BASE_URL');
    if (!key) missing.push('AICTE_AI_API_KEY');
    if (!model) missing.push('AICTE_AI_MODEL');
  }
  const configured = !!provider && !problem && missing.length === 0;
  return {
    provider: provider || null, configured, missing, problem, model: configured ? model : (model || null), key, baseUrl,
    temperature: env.AICTE_AI_TEMPERATURE === undefined || env.AICTE_AI_TEMPERATURE === '' ? null : clamp(env.AICTE_AI_TEMPERATURE, 0, 0, 1),
    limits: {
      timeoutMs: clamp(env.AICTE_AI_TIMEOUT_MS, 30000, 3000, 120000),
      maxInputChars: clamp(env.AICTE_AI_MAX_INPUT_CHARS, 36000, 2000, 200000),
      maxOutputTokens: clamp(env.AICTE_AI_MAX_OUTPUT_TOKENS, 1500, 200, 8000),
      maxFileBytes: clamp(env.AICTE_AI_MAX_FILE_BYTES, 5 * 1024 * 1024, 10 * 1024, 20 * 1024 * 1024),
      concurrency: clamp(env.AICTE_AI_CONCURRENCY, 2, 1, 8),
      userCallsPerWindow: clamp(env.AICTE_AI_USER_CALLS_PER_10_MIN, 20, 1, 500)
    },
    // Sending whole files (scans / images) to the provider is off unless explicitly enabled.
    vision: flag(env.AICTE_AI_VISION)
  };
}

// Runtime health is kept in memory only so the UI can show "configured but last call failed".
const health = { lastOkAt: null, lastError: null };
export function recordAiOutcome(error) {
  if (!error) { health.lastOkAt = new Date().toISOString(); health.lastError = null; }
  else health.lastError = { code: error.code || 'error', at: new Date().toISOString() };
}

export function publicAiStatus() {
  const c = aiConfig();
  const state = !c.configured ? 'not_configured' : health.lastError ? 'degraded' : 'configured';
  return {
    state, configured: c.configured, provider: c.provider, model: c.configured ? c.model : null,
    missing: c.missing, problem: c.problem, vision: c.configured && c.vision,
    limits: c.limits, lastOkAt: health.lastOkAt, lastError: health.lastError,
    dataNotice: 'When AI is configured, document text, extracted fields and application context are sent to the configured external provider for processing. Do not use real sensitive records without a data-processing agreement and legal review.'
  };
}

export function canUseVision(mime) {
  const c = aiConfig();
  if (!c.configured || !c.vision) return false;
  if (mime === 'application/pdf') return c.provider === 'anthropic';
  return ['image/jpeg', 'image/png'].includes(mime);
}

// Small semaphore so background document jobs cannot open unlimited provider connections.
let active = 0; const waiting = [];
async function acquire(max) { if (active < max) { active++; return; } await new Promise(r => waiting.push(r)); active++; }
function release() { active--; waiting.shift()?.(); }

function redact(text, secret) { let s = String(text ?? ''); if (secret) s = s.split(secret).join('[redacted]'); return s.slice(0, 300); }

function mapHttpError(status, secret) {
  if (status === 401 || status === 403) return new AIError('auth_failed', 'The AI provider rejected the configured credentials. Check the API key and model access.', 502);
  if (status === 404) return new AIError('model_not_found', 'The AI provider could not find the configured model or endpoint. Check AICTE_AI_MODEL and the base URL.', 502);
  if (status === 413) return new AIError('input_too_large', 'The request was too large for the AI provider.', 502);
  if (status === 429) return new AIError('rate_limited', 'The AI provider is rate limiting requests. Try again shortly.', 503);
  if (status >= 500) return new AIError('provider_unavailable', `The AI provider is temporarily unavailable (HTTP ${status}).`, 503);
  return new AIError('provider_rejected', `The AI provider rejected the request (HTTP ${status}).`, 502);
}

async function post(url, headers, body, cfg) {
  const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), cfg.limits.timeoutMs);
  try {
    const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body), signal: ctl.signal });
    if (!r.ok) { try { await r.text(); } catch { /* body intentionally ignored: never surface provider text */ } throw mapHttpError(r.status, cfg.key); }
    return await r.json();
  } catch (e) {
    if (e instanceof AIError) throw e;
    if (e?.name === 'AbortError') throw new AIError('timeout', `The AI provider did not answer within ${Math.round(cfg.limits.timeoutMs / 1000)} seconds.`, 504);
    throw new AIError('network_error', 'Could not reach the AI provider: ' + redact(e?.cause?.code || e?.message, cfg.key), 502);
  } finally { clearTimeout(timer); }
}

async function callAnthropic(cfg, { system, user, files, maxTokens }) {
  const content = [];
  for (const f of files) content.push(f.mime === 'application/pdf'
    ? { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: f.base64 } }
    : { type: 'image', source: { type: 'base64', media_type: f.mime, data: f.base64 } });
  content.push({ type: 'text', text: user });
  const body = { model: cfg.model, max_tokens: maxTokens, system, messages: [{ role: 'user', content }] };
  if (cfg.temperature !== null) body.temperature = cfg.temperature;
  const data = await post(`${cfg.baseUrl}/v1/messages`, { 'x-api-key': cfg.key, 'anthropic-version': ANTHROPIC_VERSION, 'content-type': 'application/json' }, body, cfg);
  const text = (data.content || []).filter(b => b?.type === 'text').map(b => b.text).join('');
  if (data.stop_reason === 'refusal') throw new AIError('refused', 'The AI provider declined to process this content.', 502);
  if (data.stop_reason === 'max_tokens') throw new AIError('output_truncated', 'The AI answer was cut off by the output limit. Try a narrower request.', 502);
  return { text, usage: { inputTokens: data.usage?.input_tokens ?? null, outputTokens: data.usage?.output_tokens ?? null } };
}

async function callOpenAI(cfg, { system, user, files, maxTokens }) {
  if (files.some(f => f.mime === 'application/pdf')) throw new AIError('unsupported_input', 'PDF file input requires the Anthropic provider. Use text extraction instead.', 400);
  const content = files.length
    ? [{ type: 'text', text: user }, ...files.map(f => ({ type: 'image_url', image_url: { url: `data:${f.mime};base64,${f.base64}` } }))]
    : user;
  const body = { model: cfg.model, max_tokens: maxTokens, response_format: { type: 'json_object' }, messages: [{ role: 'system', content: system }, { role: 'user', content }] };
  if (cfg.temperature !== null) body.temperature = cfg.temperature;
  const data = await post(`${cfg.baseUrl}/chat/completions`, { authorization: `Bearer ${cfg.key}`, 'content-type': 'application/json' }, body, cfg);
  const choice = data.choices?.[0];
  if (choice?.finish_reason === 'length') throw new AIError('output_truncated', 'The AI answer was cut off by the output limit. Try a narrower request.', 502);
  if (typeof choice?.message?.content !== 'string') throw new AIError('bad_output', 'The AI provider returned no content.', 502);
  return { text: choice.message.content, usage: { inputTokens: data.usage?.prompt_tokens ?? null, outputTokens: data.usage?.completion_tokens ?? null } };
}

// files: [{mime, base64}] only when vision is enabled (see canUseVision).
export async function callModel({ system, user, files = [], maxTokens }) {
  const cfg = aiConfig();
  if (!cfg.configured) throw new AIError('ai_not_configured', cfg.problem || `AI is not configured. Missing: ${cfg.missing.join(', ') || 'AICTE_AI_PROVIDER'}.`, 503);
  if (user.length > cfg.limits.maxInputChars + 4000) throw new AIError('input_too_large', 'Input exceeds the configured size limit.', 413);
  const tokens = Math.min(maxTokens || cfg.limits.maxOutputTokens, cfg.limits.maxOutputTokens);
  await acquire(cfg.limits.concurrency);
  try {
    let lastErr;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const run = cfg.provider === 'anthropic' ? callAnthropic : callOpenAI;
        const out = await run(cfg, { system, user, files, maxTokens: tokens });
        recordAiOutcome(null);
        return { ...out, provider: cfg.provider, model: cfg.model };
      } catch (e) {
        lastErr = e;
        // One short retry only for transient provider conditions.
        if (attempt === 0 && ['rate_limited', 'provider_unavailable', 'network_error'].includes(e.code)) { await new Promise(r => setTimeout(r, 800)); continue; }
        break;
      }
    }
    recordAiOutcome(lastErr);
    throw lastErr;
  } finally { release(); }
}

// Pull a JSON object out of a model reply. Throws AIError('bad_output') if none parses.
export function parseJsonObject(text) {
  const s = String(text || '').trim();
  const tries = [s, s.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '')];
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) tries.push(s.slice(a, b + 1));
  for (const t of tries) { try { const v = JSON.parse(t); if (v && typeof v === 'object' && !Array.isArray(v)) return v; } catch { /* try next */ } }
  throw new AIError('bad_output', 'The AI provider returned a reply that was not valid JSON.', 502);
}
