import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const defaultFile = path.join(here, '..', 'rules', 'compliance-rules.json');

// Loads the versioned ruleset. A rule only counts as verified when it names a source reference AND an
// effective date; otherwise it is downgraded to unverified so nothing unsourced is presented as official.
export function loadRuleset(file = process.env.AICTE_RULES_FILE || defaultFile) {
  const raw = JSON.parse(readFileSync(file, 'utf8'));
  const warnings = [];
  const rules = (raw.rules || []).map(r => {
    const verified = r.verified === true && !!r.source && !!r.effectiveFrom;
    if (r.verified === true && !verified) warnings.push(`Rule ${r.id} is marked verified but has no source and effective date; treated as unverified.`);
    return { id: String(r.id), label: String(r.label), documentCategory: String(r.documentCategory || r.id), ruleVersion: r.ruleVersion ?? 1, verified, source: r.source || null, effectiveFrom: r.effectiveFrom || null, effectiveTo: r.effectiveTo || null };
  });
  const allVerified = rules.length > 0 && rules.every(r => r.verified);
  return { rulesetId: raw.rulesetId, version: String(raw.version), status: allVerified ? 'verified' : 'illustrative_unverified', verified: allVerified, notice: raw.notice || '', rules, warnings };
}
