// Deterministic compliance and data-quality checks. No model is involved here: every check is a plain
// comparison over stored records, with the evidence listed. Checks are advisory and never decide anything.
import { documentSchemas } from './document-pipeline.mjs';

const parse = (v, d) => { try { return JSON.parse(v ?? '') ?? d; } catch { return d; } };
const sameName = (a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: 'accent' }) === 0;

// Returns a Date only when the day/month order is unambiguous; otherwise null.
export function parseDocDate(text) {
  const s = String(text || '').trim();
  let m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  let y, mo, d;
  if (m) { y = +m[1]; mo = +m[2]; d = +m[3]; }
  else if ((m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/))) {
    const a = +m[1], b = +m[2]; y = +m[3];
    if (a > 12 && b <= 12) { d = a; mo = b; } else if (b > 12 && a <= 12) { mo = a; d = b; } else if (a === b) { d = a; mo = b; } else return null;
  } else return null;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d ? dt : null;
}

const evDoc = (d, extra = {}) => ({ documentId: d.id, fileName: d.name, category: d.category, version: d.version, ...extra });

export function runComplianceChecks({ app, documents, ruleset, now = new Date() }) {
  const checks = [];
  const add = c => checks.push({ sourceType: 'deterministic_check', ...c });
  const latest = new Map();
  for (const d of documents) { const cur = latest.get(d.category); if (!cur || (d.version || 1) > (cur.version || 1)) latest.set(d.category, d); }
  const ruleBasis = r => ({ ruleId: r.id, ruleVersion: r.ruleVersion, ruleVerified: r.verified, ruleSource: r.source, ruleEffectiveFrom: r.effectiveFrom, basis: r.verified ? 'verified_checklist_rule' : 'unverified_demo_checklist_rule' });
  const dataQuality = { ruleId: null, ruleVerified: null, basis: 'data_quality_check' };

  for (const r of ruleset.rules) {
    const d = latest.get(r.documentCategory);
    if (!d) {
      add({ id: 'missing_document:' + r.id, kind: 'missing_document', severity: 'attention', title: 'No file uploaded for: ' + r.label,
        explanation: `The checklist item "${r.label}" has no uploaded file yet.` + (r.verified ? '' : ' This checklist item is a demonstration placeholder, not a verified AICTE requirement.'),
        recommendation: 'Upload the document for this item, or ask an authorised reviewer whether it applies to your case.', evidence: [{ kind: 'required_checklist_item', category: r.documentCategory }], ...ruleBasis(r) });
      continue;
    }
    const fields = parse(d.extracted_json, {}), ai = parse(d.ai_json, null);
    if (['needs_manual_ocr', 'needs_manual_review', 'failed'].includes(d.processing_status)) {
      add({ id: 'unreadable_document:' + d.id, kind: 'unreadable_document', severity: 'attention', title: `"${d.name}" could not be read automatically`,
        explanation: `The system could not read machine-readable text from "${d.name}" (status: ${String(d.processing_status).replaceAll('_', ' ')}). Nothing was extracted, so no checks could be run on its contents.`,
        recommendation: 'Upload a clearer or text-based PDF, or ask a reviewer to verify this document manually.', evidence: [evDoc(d, { processingStatus: d.processing_status, message: d.processing_message })], ...ruleBasis(r) });
    } else if (['completed_deterministic', 'completed_ai_suggestion'].includes(d.processing_status)) {
      const expected = documentSchemas[r.documentCategory]?.fields || [], absent = expected.filter(f => !fields[f]);
      if (absent.length) add({ id: 'fields_not_found:' + d.id, kind: 'fields_not_found', severity: 'review', title: `Some expected details were not found in "${d.name}"`,
        explanation: `The automatic reader did not find: ${absent.join(', ')}. This can mean the detail is missing from the document, written in a different way, or hard to read. It does not prove the document is incomplete.`,
        recommendation: 'Open the document and check whether these details are present. If they are missing, upload a corrected document.', evidence: [evDoc(d, { missingFields: absent })], ...ruleBasis(r) });
    }
    for (const i of ai?.issues || []) {
      add({ id: `ai_note:${d.id}:${i.type}:${i.field || 'general'}`, kind: 'ai_document_note', severity: 'review', title: `AI noted a ${i.type} problem in "${d.name}"`,
        explanation: `The AI reader reported: ${i.detail || 'no detail given'}. This is an AI observation, not a verified finding.` + (i.quoteVerified === false ? ' Its quoted evidence could not be found in the document text.' : ''),
        recommendation: 'Check the original document to confirm or dismiss this note.', evidence: [evDoc(d, { quote: i.evidenceQuote, quoteVerified: i.quoteVerified })], ...dataQuality, sourceType: 'ai_suggestion' });
    }
    if (ai?.status === 'provider_error') add({ id: 'ai_unavailable:' + d.id, kind: 'ai_unavailable', severity: 'info', title: `AI analysis did not complete for "${d.name}"`,
      explanation: ai.message || 'The AI provider returned an error.', recommendation: 'Retry processing later. Deterministic results (if any) are still shown.', evidence: [evDoc(d, { errorCode: ai.errorCode })], ...dataQuality });
    // date checks
    const issue = parseDocDate(fields.issueDate?.value), valid = parseDocDate(fields.validityDate?.value);
    if (issue && valid && valid < issue) add({ id: 'date_order:' + d.id, kind: 'date_order', severity: 'review', title: `Validity date is before the issue date in "${d.name}"`,
      explanation: `The document lists an issue date of ${fields.issueDate.value} and a validity date of ${fields.validityDate.value}. The validity date is earlier than the issue date. This may be a typing error or a misread date.`,
      recommendation: 'Check both dates against the original document.', evidence: [evDoc(d, { issueDate: fields.issueDate.value, validityDate: fields.validityDate.value })], ...ruleBasis(r) });
    if (valid && valid < new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()))) add({ id: 'validity_date_passed:' + d.id, kind: 'validity_date_passed', severity: 'review', title: `"${d.name}" states a validity date that has passed`,
      explanation: `The document states a validity date of ${fields.validityDate.value}, which is before today's date. This tool does not know whether a validity requirement applies to this document.`,
      recommendation: 'If a newer version of this document exists, upload it. Otherwise ask an authorised reviewer whether this matters.', evidence: [evDoc(d, { validityDate: fields.validityDate.value })], ...ruleBasis(r) });
  }

  // institution name vs application, and across documents
  const names = [];
  for (const d of latest.values()) { const v = parse(d.extracted_json, {}).institutionName?.value; if (v) names.push({ d, v }); }
  for (const { d, v } of names) if (app.institution && !sameName(v, app.institution)) add({ id: 'institution_name_mismatch:' + d.id, kind: 'institution_name_mismatch', severity: 'review', title: `Institution name in "${d.name}" differs from the application`,
    explanation: `The application names "${app.institution}" but this document names "${v}". Differences can come from abbreviations, spelling, or a different legal entity.`, recommendation: 'Confirm which name is correct, then correct the application or upload a corrected document. If both are valid, explain the difference to the reviewer.',
    evidence: [evDoc(d, { extracted: v, application: app.institution })], ...dataQuality });
  for (let i = 0; i < names.length; i++) for (let j = i + 1; j < names.length; j++) if (!sameName(names[i].v, names[j].v)) {
    const A = names[i], B = names[j];
    add({ id: `cross_document_name:${A.d.id}:${B.d.id}`, kind: 'cross_document_name_mismatch', severity: 'review', title: 'Documents give different institution names',
      explanation: `"${A.d.name}" names "${A.v}" while "${B.d.name}" names "${B.v}".`, recommendation: 'Check both documents and clarify which name is correct.', evidence: [evDoc(A.d, { extracted: A.v }), evDoc(B.d, { extracted: B.v })], ...dataQuality });
  }

  // duplicates inside this application: identical file bytes under different uploads
  const bySha = new Map();
  for (const d of documents) { if (!d.sha) continue; (bySha.get(d.sha) || bySha.set(d.sha, []).get(d.sha)).push(d); }
  for (const [sha, list] of bySha) if (list.length > 1) add({ id: 'duplicate_upload:' + sha.slice(0, 16), kind: 'duplicate_upload', severity: 'review', title: 'The same file was uploaded more than once',
    explanation: `${list.length} uploads have identical file content: ${list.map(d => `"${d.name}" (${d.category}, v${d.version})`).join(', ')}.` + (new Set(list.map(d => d.category)).size > 1 ? ' They are filed under different checklist items, so one of them may be in the wrong place.' : ' A re-upload with no changes does not correct anything.'),
    recommendation: 'Confirm the repeat is intended. If a different document was meant for one of the items, upload the correct file.', evidence: list.map(d => evDoc(d, { sha256: sha })), ...dataQuality });

  const order = { attention: 0, review: 1, info: 2 };
  checks.sort((a, b) => order[a.severity] - order[b.severity]);
  return checks;
}
