import { createServer } from 'node:http';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';
import { randomUUID, createHash, scryptSync, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './src/env.mjs';
import { processDocument, compareExtraction, buildComplianceReport, documentSchemas } from './src/document-pipeline.mjs';
import { publicAiStatus, AIError } from './src/ai-provider.mjs';
import { loadRuleset } from './src/rules.mjs';
import { runComplianceChecks } from './src/compliance-check.mjs';
import { buildContext, runAssistantTask, taskCacheKey } from './src/ai-assistant.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const work=process.env.APP_DATA_DIR||path.join(root,'work');
const uploadDir=path.join(work,'uploads');
await mkdir(uploadDir,{recursive:true});
const db=new DatabaseSync(path.join(work,'demo.sqlite'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,role TEXT NOT NULL,institution TEXT,salt TEXT NOT NULL,password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS apps(id TEXT PRIMARY KEY,institution TEXT,category TEXT,year TEXT,programme TEXT,state TEXT,created TEXT,owner_id TEXT);
CREATE TABLE IF NOT EXISTS docs(id TEXT PRIMARY KEY,app_id TEXT,name TEXT,category TEXT,sha TEXT,added TEXT,mime TEXT,size INTEGER,processing_status TEXT DEFAULT 'queued',document_type TEXT,extraction_method TEXT,extracted_json TEXT,changes_json TEXT,processing_message TEXT,processed_at TEXT,version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,app_id TEXT,actor TEXT,action TEXT,from_state TEXT,to_state TEXT,reason TEXT,at TEXT,prev TEXT,hash TEXT);
CREATE TABLE IF NOT EXISTS findings(id TEXT PRIMARY KEY,app_id TEXT,issue TEXT,rule TEXT,evidence TEXT,status TEXT,evidence_json TEXT,severity TEXT,recommendation TEXT,source_type TEXT);`);
const cols=db.prepare('PRAGMA table_info(apps)').all().map(c=>c.name);
if(!cols.includes('owner_id'))db.exec('ALTER TABLE apps ADD COLUMN owner_id TEXT');
if(!cols.includes('reviewer_note'))db.exec('ALTER TABLE apps ADD COLUMN reviewer_note TEXT');
const docCols=db.prepare('PRAGMA table_info(docs)').all().map(c=>c.name);
if(!docCols.includes('mime'))db.exec('ALTER TABLE docs ADD COLUMN mime TEXT');
if(!docCols.includes('size'))db.exec('ALTER TABLE docs ADD COLUMN size INTEGER');
for(const [name,type] of [['processing_status',"TEXT DEFAULT 'queued'"],['document_type','TEXT'],['extraction_method','TEXT'],['extracted_json','TEXT'],['changes_json','TEXT'],['processing_message','TEXT'],['processed_at','TEXT'],['version','INTEGER DEFAULT 1']])if(!docCols.includes(name))db.exec('ALTER TABLE docs ADD COLUMN '+name+' '+type);
const findingCols=db.prepare('PRAGMA table_info(findings)').all().map(c=>c.name);
for(const [name,type] of [['evidence_json','TEXT'],['severity','TEXT'],['recommendation','TEXT'],['source_type','TEXT']])if(!findingCols.includes(name))db.exec('ALTER TABLE findings ADD COLUMN '+name+' '+type);
for(const [name,type] of [['ai_json','TEXT'],['ai_status','TEXT']])if(!docCols.includes(name))db.exec('ALTER TABLE docs ADD COLUMN '+name+' '+type);
db.exec("CREATE TABLE IF NOT EXISTS ai_cache(key TEXT PRIMARY KEY,task TEXT,app_id TEXT,created TEXT,result_json TEXT); CREATE TABLE IF NOT EXISTS ai_runs(id TEXT PRIMARY KEY,app_id TEXT,user_id TEXT,task TEXT,status TEXT,cached INTEGER,error_code TEXT,input_tokens INTEGER,output_tokens INTEGER,created TEXT);");
db.prepare('DELETE FROM ai_cache WHERE created<?').run(new Date(Date.now()-30*86400000).toISOString());
db.exec("CREATE TABLE IF NOT EXISTS document_jobs(id TEXT PRIMARY KEY,app_id TEXT,document_id TEXT,stage TEXT,status TEXT,attempts INTEGER DEFAULT 0,created TEXT,updated TEXT,message TEXT,result_json TEXT); CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,app_id TEXT,kind TEXT,message TEXT,status TEXT,created TEXT); CREATE TABLE IF NOT EXISTS final_decisions(id TEXT PRIMARY KEY,app_id TEXT NOT NULL,decision_number INTEGER NOT NULL,outcome TEXT NOT NULL,reason TEXT NOT NULL,actor_id TEXT NOT NULL,actor_email TEXT NOT NULL,created TEXT NOT NULL,report_hash TEXT NOT NULL,report_snapshot TEXT NOT NULL,UNIQUE(app_id,decision_number));");
const seedUser=(id,email,role,institution)=>{
 if(db.prepare('SELECT id FROM users WHERE id=?').get(id))return;
 const salt=randomUUID();const hash=scryptSync('Demo1234!',salt,64).toString('hex');
 db.prepare('INSERT INTO users(id,email,role,institution,salt,password_hash) VALUES(?,?,?,?,?,?)').run(id,email,role,institution,salt,hash);
};
seedUser('institution-demo','institution@example.test','institution','Northstar Institute of Technology');
seedUser('evaluator-demo','evaluator@example.test','evaluator',null);
seedUser('decision-maker-demo','decision-maker@example.test','decision_maker',null);
db.prepare('UPDATE apps SET owner_id=? WHERE owner_id IS NULL').run('institution-demo');
if(!db.prepare('SELECT id FROM apps LIMIT 1').get()){
 const id=randomUUID();db.prepare('INSERT INTO apps(id,institution,category,year,programme,state,created,owner_id) VALUES(?,?,?,?,?,?,?,?)').run(id,'Northstar Institute of Technology','Extension of Approval','2026-27','Computer Engineering','Draft',new Date().toISOString(),'institution-demo');
 db.prepare('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?)').run(randomUUID(),id,'system','Synthetic demo case created','','Draft','Seed data',new Date().toISOString(),'GENESIS','seed');
}
const ruleset=loadRuleset();
const rules=ruleset.rules.map(r=>[r.id,r.label]);
const categories=['New Institution Approval','Extension of Approval','Renewal','Change Request'];
const sessions=new Map(),loginAttempts=new Map();
const send=(res,status,obj,type='application/json',extra={})=>{res.writeHead(status,{'content-type':type,'x-content-type-options':'nosniff','cache-control':'no-store',...extra});res.end(type.includes('json')?JSON.stringify(obj):obj)};
function event(app,actor,action,from,to,reason){const prev=db.prepare('SELECT hash FROM events WHERE app_id=? ORDER BY rowid DESC LIMIT 1').get(app)?.hash||'GENESIS';const at=new Date().toISOString();const hash=createHash('sha256').update([app,actor,action,from,to,reason,at,prev].join('|')).digest('hex');db.prepare('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?)').run(randomUUID(),app,actor,action,from,to,reason,at,prev,hash)}
function actor(req){const cookie=req.headers.cookie||'';const token=cookie.match(/(?:^|;\s*)sid=([a-f0-9-]+)/)?.[1];const session=token&&sessions.get(token);if(!session)return null;if(session.expires<Date.now()){sessions.delete(token);return null}return session.user}
function owns(user,app){return user.role==='evaluator'||user.role==='decision_maker'||app.owner_id===user.id}
function visible(user){const q=user.role==='institution'?db.prepare('SELECT * FROM apps WHERE owner_id=? ORDER BY created DESC').all(user.id):db.prepare('SELECT * FROM apps ORDER BY created DESC').all();return q.map(a=>({...a,documents:db.prepare('SELECT id,name,category,sha,added,mime,size,processing_status,document_type,extraction_method,extracted_json,changes_json,processing_message,processed_at,version,ai_json,ai_status FROM docs WHERE app_id=?').all(a.id),findings:db.prepare('SELECT * FROM findings WHERE app_id=?').all(a.id),events:db.prepare('SELECT * FROM events WHERE app_id=? ORDER BY rowid').all(a.id),jobs:db.prepare('SELECT * FROM document_jobs WHERE app_id=? ORDER BY created DESC').all(a.id),decisions:db.prepare('SELECT * FROM final_decisions WHERE app_id=? ORDER BY decision_number').all(a.id)}))}
function parseBody(req,max=15*1024*1024){return new Promise((resolve,reject)=>{let raw='',size=0;req.on('data',chunk=>{size+=chunk.length;if(size>max){reject(Object.assign(new Error('Request is too large'),{status:413}));req.destroy();return}raw+=chunk.toString()});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'))}catch{reject(Object.assign(new Error('Invalid JSON request'),{status:400}))}});req.on('error',reject)})}
function appById(id){return db.prepare('SELECT * FROM apps WHERE id=?').get(id)}
function hashPassword(password,salt){return scryptSync(password,salt,64)}
function insertFinding(appId,{issue,rule,evidence=[],severity='review',recommendation='Review the source evidence and confirm the appropriate next step.',sourceType='deterministic_check'}){
 db.prepare('INSERT INTO findings(id,app_id,issue,rule,evidence,status,evidence_json,severity,recommendation,source_type) VALUES(?,?,?,?,?,?,?,?,?,?)').run(randomUUID(),appId,issue,rule,JSON.stringify(evidence), 'Open',JSON.stringify(evidence),severity,recommendation,sourceType);
}
function notify(appId,kind,message){db.prepare('INSERT INTO notifications VALUES(?,?,?,?,?,?)').run(randomUUID(),appId,kind,message,'unread',new Date().toISOString())}
function queueDocumentJobAgain(jobId,docId){db.prepare("UPDATE docs SET processing_status='queued' WHERE id=?").run(docId);setTimeout(()=>runDocumentJob(jobId),5)}
function queueDocumentJob(docId,appId){const id=randomUUID(),now=new Date().toISOString();db.prepare('INSERT INTO document_jobs VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,appId,docId,'queued','queued',0,now,now,null,null);db.prepare("UPDATE docs SET processing_status='queued' WHERE id=?").run(docId);setTimeout(()=>runDocumentJob(id),5);return id}
function aiCache(appId){return{get:k=>{const r=db.prepare('SELECT result_json FROM ai_cache WHERE key=?').get(k);try{return r?JSON.parse(r.result_json):null}catch{return null}},set:(k,v)=>db.prepare('INSERT OR REPLACE INTO ai_cache(key,task,app_id,created,result_json) VALUES(?,?,?,?,?)').run(k,v.promptVersion||'',appId,new Date().toISOString(),JSON.stringify(v))}}
function aiLog(appId,userId){return e=>db.prepare('INSERT INTO ai_runs VALUES(?,?,?,?,?,?,?,?,?,?)').run(randomUUID(),appId,userId||null,e.task,e.status,e.cached?1:0,e.errorCode||null,e.usage?.inputTokens??null,e.usage?.outputTokens??null,new Date().toISOString())}
const aiCalls=new Map();
function aiGate(user){return()=>{const limit=publicAiStatus().limits.userCallsPerWindow,now=Date.now(),list=(aiCalls.get(user.id)||[]).filter(t=>now-t<600000);if(list.length>=limit)throw new AIError('user_rate_limited','You have reached the AI request limit for this period. Try again in a few minutes.',429);list.push(now);aiCalls.set(user.id,list)}}
const OUTSTANDING_KINDS=new Set(['missing_document','unreadable_document','institution_name_mismatch','cross_document_name_mismatch','duplicate_upload','date_order']);
function appAI(a,user){const documents=db.prepare('SELECT * FROM docs WHERE app_id=? ORDER BY category,version').all(a.id),findings=db.prepare('SELECT * FROM findings WHERE app_id=? ORDER BY rowid').all(a.id),events=db.prepare('SELECT * FROM events WHERE app_id=? ORDER BY rowid').all(a.id),checks=runComplianceChecks({app:a,documents,ruleset}),{ctx,index}=buildContext({app:a,role:user.role,ruleset,documents,checks,findings,events});
 const hasMissing=checks.some(c=>c.kind==='missing_document');const outstanding=[...checks.filter(c=>OUTSTANDING_KINDS.has(c.kind)).map(c=>({source:'check',id:c.id,severity:c.severity,title:c.title,recommendation:c.recommendation})),...findings.filter(f=>f.status==='Open'&&!(hasMissing&&String(f.issue).startsWith('Evidence missing:'))).map(f=>({source:'recorded_finding',id:f.id,severity:f.severity||'review',title:f.issue,recommendation:f.recommendation||'Review the source evidence and confirm the next step.',origin:f.source_type}))];
 return{documents,findings,checks,outstanding,ctx,index}}
async function handleAI(req,res,user,a,op){
 const t=appAI(a,user),cache=aiCache(a.id),log=aiLog(a.id,user.id),base={role:user.role,ctx:t.ctx,index:t.index,cache,log,appId:a.id,userId:user.id};
 const fail=e=>send(res,e.status||502,{error:e.message,code:e.code||'ai_error'});
 if(op==='ai/analysis'&&req.method==='GET'){const peek=task=>cache.get(taskCacheKey({task,role:user.role,ctx:t.ctx,appId:a.id,userId:user.id}));return send(res,200,{application:{id:a.id,state:a.state},ruleset:{id:ruleset.rulesetId,version:ruleset.version,status:ruleset.status,verified:ruleset.verified,notice:ruleset.notice},checks:t.checks,outstanding:t.outstanding,cached:{summary:peek('summary')?{...peek('summary'),cached:true}:null,explain:peek('explain')?{...peek('explain'),cached:true}:null},ai:publicAiStatus(),notice:'Checks are deterministic comparisons over stored records. They are advisory, use unverified demonstration rules, and never decide an application.'})}
 if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
 if(!publicAiStatus().configured)return send(res,503,{error:'AI is not configured on this server. Ask the administrator to set the AI provider environment variables.',code:'ai_not_configured'});
 const b=await parseBody(req,16000);
 try{
  if(op==='ai/summary')return send(res,200,await runAssistantTask({...base,task:'summary',gate:aiGate(user),force:b.refresh===true}));
  if(op==='ai/explain')return send(res,200,await runAssistantTask({...base,task:'explain',gate:aiGate(user),force:b.refresh===true}));
  if(op==='ai/ask'){const q=typeof b.question==='string'?b.question.trim():'';if(q.length<3||q.length>500)return send(res,400,{error:'Enter a question between 3 and 500 characters'});return send(res,200,await runAssistantTask({...base,task:'ask',question:q,gate:aiGate(user)}))}
 }catch(e){return fail(e)}
 return send(res,404,{error:'Not found'});
}

async function runDocumentJob(jobId){
 const job=db.prepare('SELECT * FROM document_jobs WHERE id=?').get(jobId);if(!job)return;const now=new Date().toISOString();db.prepare("UPDATE document_jobs SET stage='text_extraction',status='running',attempts=attempts+1,updated=? WHERE id=?").run(now,jobId);db.prepare("UPDATE docs SET processing_status='processing' WHERE id=?").run(job.document_id);
 try{
  const doc=db.prepare('SELECT * FROM docs WHERE id=?').get(job.document_id),app=appById(job.app_id);
  const previous=db.prepare('SELECT extracted_json FROM docs WHERE app_id=? AND category=? AND version<? ORDER BY version DESC LIMIT 1').get(doc.app_id,doc.category,doc.version);
  const result=await processDocument({filePath:path.join(uploadDir,doc.id),mime:doc.mime,category:doc.category,app,hooks:{cache:aiCache(app.id),log:aiLog(app.id,null)}});
  const changes=compareExtraction(previous?.extracted_json,result.fields);
  db.prepare('UPDATE docs SET processing_status=?,document_type=?,extraction_method=?,extracted_json=?,changes_json=?,processing_message=?,processed_at=?,ai_json=?,ai_status=? WHERE id=?').run(result.status,result.documentType,result.method,JSON.stringify(result.fields),JSON.stringify(changes),result.message,new Date().toISOString(),JSON.stringify(result.ai||null),result.ai?.status||'not_configured',doc.id);
  for(const item of result.consistency||[]){const issue=item.kind==='extraction_disagreement'?'Automatic readers disagree on '+item.field:'Potential inconsistency in '+item.field;if(!db.prepare("SELECT id FROM findings WHERE app_id=? AND rule='DATA-CONSISTENCY' AND status='Open' AND issue=?").get(app.id,issue))insertFinding(app.id,{issue,rule:'DATA-CONSISTENCY',evidence:[{documentId:doc.id,fileName:doc.name,...item}],recommendation:item.kind==='extraction_disagreement'?'Check the original document to see which value is correct. The label-pattern value was kept; the AI value is only a suggestion.':'Compare the extracted text with the original document and application entry. Correct the data or provide clarification.',sourceType:item.source})}
  const duplicate=db.prepare('SELECT id,app_id FROM docs WHERE sha=? AND id<>? LIMIT 1').get(doc.sha,doc.id);
  if(duplicate&&!db.prepare("SELECT id FROM findings WHERE app_id=? AND rule='POSSIBLE-DUPLICATE' AND evidence_json LIKE ?").get(app.id,'%'+doc.id+'%'))insertFinding(app.id,{issue:'Potential duplicate file detected',rule:'POSSIBLE-DUPLICATE',evidence:[{documentId:doc.id,relatedDocumentId:duplicate.id,sha256:doc.sha}],recommendation:'Review both records and confirm whether this repeated file is intended.',sourceType:'sha256_duplicate_check'});
  if(changes.length)notify(app.id,'document_changes',doc.name+' contains changes in '+changes.map(c=>c.field).join(', ')+'. Review the new version and comparison evidence.');
  const status=['needs_manual_ocr','needs_manual_review','failed'].includes(result.status)?'needs_review':'completed';
  db.prepare('UPDATE document_jobs SET stage=?,status=?,updated=?,message=?,result_json=? WHERE id=?').run(status,status,new Date().toISOString(),result.message,JSON.stringify({processingStatus:result.status,documentType:result.documentType,method:result.method}),jobId);
  notify(app.id,'document_processing',doc.name+': '+result.status.replaceAll('_',' ')+(result.message?' — '+result.message:''));
  event(app.id,'document-worker','Document processing '+status,app.state,app.state,'Method: '+result.method+'; status: '+result.status+'; job: '+jobId);
 }catch(error){db.prepare("UPDATE docs SET processing_status='failed',processing_message=?,processed_at=? WHERE id=?").run(error.message,new Date().toISOString(),job.document_id);db.prepare("UPDATE document_jobs SET stage='failed',status='failed',updated=?,message=? WHERE id=?").run(new Date().toISOString(),error.message,jobId);notify(job.app_id,'document_processing_failed','Document processing failed. Retry the job or route the document for manual verification.');}
}

const server=createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&url.pathname==='/')return send(res,200,await readFile(path.join(root,'index.html'),'utf8'),'text/html; charset=utf-8');
 if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,storage:'local-demo'});
 if(req.method==='POST'&&url.pathname==='/api/login'){
  const ip=req.socket.remoteAddress||'local';const now=Date.now();const entry=loginAttempts.get(ip)||{count:0,until:now+60000};if(now>entry.until){entry.count=0;entry.until=now+60000}if(entry.count>=10)return send(res,429,{error:'Too many sign-in attempts. Wait one minute.'});entry.count++;loginAttempts.set(ip,entry);
  const b=await parseBody(req);const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(b.email||'').toLowerCase());let good=false;if(u&&typeof b.password==='string'&&b.password.length<=256){const attempt=hashPassword(b.password,u.salt);good=timingSafeEqual(attempt,Buffer.from(u.password_hash,'hex'))}if(!good)return send(res,401,{error:'Email or password is incorrect'});
  loginAttempts.delete(ip);const token=randomUUID();sessions.set(token,{user:{id:u.id,email:u.email,role:u.role,institution:u.institution},expires:now+8*60*60*1000});return send(res,200,{user:sessions.get(token).user},'application/json',{'set-cookie':`sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`});
 }
 if(req.method==='POST'&&url.pathname==='/api/logout'){const token=(req.headers.cookie||'').match(/(?:^|;\s*)sid=([a-f0-9-]+)/)?.[1];if(token)sessions.delete(token);return send(res,200,{ok:true},'application/json',{'set-cookie':'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})}
 if(url.pathname==='/api/me'&&req.method==='GET'){const user=actor(req);return user?send(res,200,{user}):send(res,401,{error:'Sign in required'})}
 const user=actor(req);if(!user)return send(res,401,{error:'Sign in required'});
 if(req.method==='GET'&&url.pathname==='/api/ai/status')return send(res,200,{...publicAiStatus(),documentPipeline:'local-native-pdf-and-label-heuristics',schemas:documentSchemas,ocr:process.env.AICTE_TESSERACT_PATH?'configured_tesseract':'unavailable',notice:publicAiStatus().configured?'AI output is advisory. Document text and application context are sent to the configured external provider.':'No model is called unless an AI provider, key and model are configured on the server.'});
 if(req.method==='GET'&&url.pathname==='/api/applications')return send(res,200,visible(user));
 if(req.method==='GET'&&url.pathname==='/api/jobs'){const q=user.role==='evaluator'?db.prepare('SELECT j.*,d.name AS file_name FROM document_jobs j JOIN docs d ON d.id=j.document_id ORDER BY j.created DESC LIMIT 100').all():db.prepare('SELECT j.*,d.name AS file_name FROM document_jobs j JOIN docs d ON d.id=j.document_id JOIN apps a ON a.id=j.app_id WHERE a.owner_id=? ORDER BY j.created DESC LIMIT 100').all(user.id);return send(res,200,q)}
 if(req.method==='POST'&&url.pathname.match(/^\/api\/notifications\/[a-f0-9-]+\/read$/)){const id=url.pathname.split('/')[3],note=db.prepare('SELECT * FROM notifications WHERE id=?').get(id),app=note&&appById(note.app_id);if(!note||!app||!owns(user,app))return send(res,404,{error:'Notification not found'});db.prepare("UPDATE notifications SET status='read' WHERE id=?").run(id);return send(res,200,{ok:true})}
 if(req.method==='GET'&&url.pathname==='/api/notifications'){const q=user.role==='institution'?db.prepare('SELECT n.*,a.institution FROM notifications n JOIN apps a ON a.id=n.app_id WHERE a.owner_id=? ORDER BY n.created DESC LIMIT 100').all(user.id):db.prepare('SELECT n.*,a.institution FROM notifications n JOIN apps a ON a.id=n.app_id ORDER BY n.created DESC LIMIT 100').all();return send(res,200,q)}
 if(req.method==='GET'&&url.pathname==='/api/decision-queue'){if(user.role!=='decision_maker')return send(res,403,{error:'Authorized decision-maker role required'});return send(res,200,db.prepare("SELECT a.id,a.institution,a.category,a.programme,a.year,a.state,a.created,COUNT(CASE WHEN f.status='Open' THEN 1 END) AS open_findings FROM apps a LEFT JOIN findings f ON f.app_id=a.id WHERE a.state='Recommendation recorded' GROUP BY a.id ORDER BY open_findings DESC,a.created ASC").all())}
 if(req.method==='GET'&&url.pathname==='/api/review-queue'){if(user.role!=='evaluator')return send(res,403,{error:'Evaluator role required'});return send(res,200,db.prepare("SELECT a.id,a.institution,a.category,a.programme,a.year,a.state,a.created,COUNT(CASE WHEN f.status='Open' THEN 1 END) AS open_findings FROM apps a LEFT JOIN findings f ON f.app_id=a.id WHERE a.state='Submitted' GROUP BY a.id ORDER BY open_findings DESC,a.created ASC").all())}
 if(req.method==='POST'&&url.pathname.startsWith('/api/jobs/')&&url.pathname.endsWith('/retry')){const id=url.pathname.split('/')[3],job=db.prepare('SELECT * FROM document_jobs WHERE id=?').get(id);if(!job)return send(res,404,{error:'Job not found'});const app=appById(job.app_id);if(!app||!owns(user,app))return send(res,404,{error:'Job not found'});if(!['failed','needs_review'].includes(job.status)||job.attempts>=3)return send(res,409,{error:'This job cannot be retried'});db.prepare("UPDATE document_jobs SET status='queued',stage='queued',updated=?,message=NULL WHERE id=?").run(new Date().toISOString(),id);queueDocumentJobAgain(id,job.document_id);event(app.id,user.email,'Document processing retried',app.state,app.state,'Job '+id+'; attempt '+(job.attempts+1));return send(res,202,{id,status:'queued'})}
 if(req.method==='GET'&&url.pathname==='/api/rules')return send(res,200,{status:ruleset.status==='verified'?'verified':'illustrative-only',rulesetVersion:ruleset.version,notice:ruleset.notice,rules:ruleset.rules.map(r=>({id:r.id,label:r.label,requirement:r.verified?'verified':'placeholder',verified:r.verified,ruleVersion:r.ruleVersion,source:r.source,effectiveFrom:r.effectiveFrom,effectiveYear:r.effectiveFrom?String(r.effectiveFrom).slice(0,4):null})),categories});
 if(req.method==='POST'&&url.pathname==='/api/applications'){
  if(user.role!=='institution')return send(res,403,{error:'Institution role required'});const b=await parseBody(req,64000);
  if(!b.category||!categories.includes(b.category)||!String(b.programme||'').trim()||!/^\d{4}-\d{2}$/.test(b.year||''))return send(res,400,{error:'Choose a listed category and provide a programme and academic year in YYYY-YY format'});
  const id=randomUUID();db.prepare('INSERT INTO apps(id,institution,category,year,programme,state,created,owner_id) VALUES(?,?,?,?,?,?,?,?)').run(id,user.institution,b.category,b.year,b.programme.trim(),'Draft',new Date().toISOString(),user.id);event(id,user.email,'Draft created','','Draft','Created through institution workspace');return send(res,201,{id});
 }
 const m=url.pathname.match(/^\/api\/applications\/([a-f0-9-]+)(?:\/(submit|review|document|report|jobs|decision|decision-document|ai\/(?:analysis|summary|explain|ask)|documents\/([a-f0-9-]+)))?$/);
 if(m){const a=appById(m[1]);if(!a)return send(res,404,{error:'Application not found'});if(!owns(user,a))return send(res,404,{error:'Application not found'});const op=m[2];
  if(op?.startsWith('ai/'))return handleAI(req,res,user,a,op);
  if(req.method==='GET'&&op==='decision-document'){const d=db.prepare('SELECT * FROM final_decisions WHERE app_id=? ORDER BY decision_number DESC LIMIT 1').get(a.id);if(!d)return send(res,404,{error:'No final decision has been recorded'});const record={title:'DEMONSTRATION DECISION RECORD — NOT AN OFFICIAL AICTE DOCUMENT',application:{id:a.id,institution:a.institution,category:a.category,programme:a.programme,academicYear:a.year},decision:{number:d.decision_number,outcome:d.outcome,reason:d.reason,authorizedActor:d.actor_email,recordedAt:d.created,reportSha256:d.report_hash},notice:'This local demonstration record is not an AICTE approval, rejection, or official communication.'};return send(res,200,record,'application/json',{'content-disposition':'attachment; filename=demo-decision-'+a.id+'.json'})}
  if(req.method==='POST'&&op==='decision'){if(user.role!=='decision_maker')return send(res,403,{error:'Authorized decision-maker role required'});if(a.state!=='Recommendation recorded')return send(res,409,{error:'Application is not awaiting final decision'});const b=await parseBody(req,64000),outcomes={approve:'Approved',reject:'Rejected',return:'Returned'};if(!Object.hasOwn(outcomes,b.outcome))return send(res,400,{error:'Choose approve, reject, or return'});const reason=String(b.reason||'').trim();if(reason.length<10||reason.length>2000)return send(res,400,{error:'Provide a reason between 10 and 2000 characters'});const report=buildComplianceReport(a,db.prepare('SELECT * FROM docs WHERE app_id=? ORDER BY category,version').all(a.id),db.prepare('SELECT * FROM findings WHERE app_id=? ORDER BY rowid').all(a.id));const snapshot=JSON.stringify(report),reportHash=createHash('sha256').update(snapshot).digest('hex'),number=(db.prepare('SELECT MAX(decision_number) n FROM final_decisions WHERE app_id=?').get(a.id).n||0)+1,id=randomUUID(),next=outcomes[b.outcome],at=new Date().toISOString();db.prepare('INSERT INTO final_decisions VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,a.id,number,b.outcome,reason,user.id,user.email,at,reportHash,snapshot);db.prepare('UPDATE apps SET state=?,reviewer_note=? WHERE id=?').run(next,reason,a.id);if(b.outcome==='return')insertFinding(a.id,{issue:'Decision-maker requested additional information: '+reason,rule:'Human final review',evidence:[{decisionId:id,actor:user.email}],recommendation:'Address the authorized decision-maker’s request and resubmit for review.',sourceType:'human_decision'});event(a.id,user.email,'Final human decision: '+b.outcome,'Recommendation recorded',next,reason+'; report SHA-256 '+reportHash);notify(a.id,'final_decision','A human decision-maker recorded '+b.outcome+'. Open the application to review the reason and decision record.');return send(res,201,{id,decisionNumber:number,outcome:b.outcome,state:next,reportHash,recordedAt:at})}
  if(req.method==='GET'&&op==='report'){const documents=db.prepare('SELECT * FROM docs WHERE app_id=? ORDER BY category,version').all(a.id),findings=db.prepare('SELECT * FROM findings WHERE app_id=? ORDER BY rowid').all(a.id);return send(res,200,buildComplianceReport(a,documents,findings))}
  if(req.method==='GET'&&op==='jobs')return send(res,200,db.prepare('SELECT * FROM document_jobs WHERE app_id=? ORDER BY created DESC').all(a.id));
  if(req.method==='GET'&&m[3]){const d=db.prepare('SELECT * FROM docs WHERE id=? AND app_id=?').get(m[3],a.id);if(!d)return send(res,404,{error:'Document not found'});const bytes=await readFile(path.join(uploadDir,d.id));return send(res,200,bytes,d.mime||'application/octet-stream',{'content-disposition':`attachment; filename*=UTF-8''${encodeURIComponent(d.name)}`,'content-length':String(bytes.length)})}
  if(req.method==='POST'&&op==='submit'){
   if(user.role!=='institution')return send(res,403,{error:'Institution role required'});if(!['Draft','Returned'].includes(a.state))return send(res,409,{error:'This stage cannot be submitted'});
   const missing=rules.filter(([r])=>!db.prepare('SELECT id FROM docs WHERE app_id=? AND category=?').get(a.id,r));for(const [r,label] of rules){const hasDoc=!!db.prepare('SELECT id FROM docs WHERE app_id=? AND category=?').get(a.id,r);if(hasDoc)db.prepare("UPDATE findings SET status='Resolved on resubmission' WHERE app_id=? AND rule=? AND status='Open' AND issue LIKE 'Evidence missing:%'").run(a.id,r);else if(!db.prepare("SELECT id FROM findings WHERE app_id=? AND rule=? AND status='Open' AND issue LIKE 'Evidence missing:%'").get(a.id,r))insertFinding(a.id,{issue:'Evidence missing: '+label,rule:r,evidence:[{kind:'required_checklist_item',category:r}],recommendation:'Upload the requested document or contact an authorized reviewer if it does not apply.',sourceType:'deterministic_checklist'})}
   db.prepare('UPDATE apps SET state=? WHERE id=?').run('Submitted',a.id);event(a.id,user.email,'Submitted',a.state,'Submitted','Institution submitted the application');notify(a.id,'submission','Application submitted. Review the preliminary checklist and any outstanding findings.');if(missing.length)notify(a.id,'preliminary_findings',missing.length+' illustrative checklist item(s) are missing. Upload evidence or request authorized clarification.');return send(res,200,{state:'Submitted',missing:missing.map(x=>x[1])});
  }
  if(req.method==='POST'&&op==='review'){
   if(user.role!=='evaluator')return send(res,403,{error:'Evaluator role required'});const b=await parseBody(req,64000);if(!['return','recommend'].includes(b.action))return send(res,400,{error:'Action must be return or recommend'});if(b.action==='return'&&!String(b.reason||'').trim())return send(res,400,{error:'A reason is required'});if(a.state!=='Submitted')return send(res,409,{error:'Application is not awaiting review'});
   const next=b.action==='return'?'Returned':'Recommendation recorded';if(b.action==='return')insertFinding(a.id,{issue:'Reviewer clarification: '+String(b.reason).trim(),rule:'Human review',evidence:[{kind:'reviewer_note',actor:user.email}],recommendation:'Address the reviewer clarification and resubmit supporting evidence.',sourceType:'human_reviewer'});db.prepare('UPDATE apps SET state=?,reviewer_note=? WHERE id=?').run(next,String(b.reason||'').trim(),a.id);event(a.id,user.email,b.action,a.state,next,String(b.reason||''));notify(a.id,b.action==='recommend'?'decision_queue':'review_return',b.action==='recommend'?'Evaluator recommendation recorded. Application is awaiting an authorized human decision.':'Evaluator returned the application for institutional clarification.');return send(res,200,{state:next});
  }
  if(req.method==='POST'&&op==='document'){
   if(user.role!=='institution')return send(res,403,{error:'Institution role required'});if(!['Draft','Returned'].includes(a.state))return send(res,409,{error:'Uploads are closed at this stage'});const b=await parseBody(req,15*1024*1024);if(!['application/pdf','image/jpeg','image/png'].includes(b.type)||typeof b.data!=='string'||!b.name||!rules.some(([r])=>r===b.category))return send(res,415,{error:'Choose a PDF, JPEG or PNG file and a checklist category'});
   const bytes=Buffer.from(b.data,'base64');if(!bytes.length||bytes.length>10*1024*1024)return send(res,413,{error:'File must be between 1 byte and 10 MB'});const signature=b.type==='application/pdf'?bytes.subarray(0,5).toString()==='%PDF-':b.type==='image/jpeg'?bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff:bytes.length>=8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));if(!signature)return send(res,415,{error:'File content does not match the selected type'});
   const sha=createHash('sha256').update(bytes).digest('hex');const id=randomUUID();const version=(db.prepare('SELECT MAX(version) AS n FROM docs WHERE app_id=? AND category=?').get(a.id,b.category).n||0)+1;await writeFile(path.join(uploadDir,id),bytes,{flag:'wx'});const cleanName=path.basename(b.name).slice(0,180);db.prepare('INSERT INTO docs(id,app_id,name,category,sha,added,mime,size,processing_status,version) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,a.id,cleanName,b.category,sha,new Date().toISOString(),b.type,bytes.length,'queued',version);event(a.id,user.email,'Evidence uploaded',a.state,a.state,'File '+cleanName+'; category '+b.category+'; SHA-256 '+sha+'; version '+version);const jobId=queueDocumentJob(id,a.id);return send(res,201,{ok:true,sha,documentId:id,jobId,status:'queued',version});
  }
 }
 return send(res,404,{error:'Not found'});
}catch(e){if(!res.headersSent)send(res,e.status||500,{error:e.status?e.message:'Request failed'});else res.destroy()}});
for(const job of db.prepare("SELECT id,document_id FROM document_jobs WHERE status IN ('queued','running')").all()){if(job.document_id)queueDocumentJobAgain(job.id,job.document_id)}
if(process.env.NODE_ENV!=='test')server.listen(Number(process.env.PORT)||4173,'127.0.0.1',()=>console.log(`Demo at http://localhost:${Number(process.env.PORT)||4173}`));
export { server, db };





