# Document automation pipeline

```mermaid
flowchart LR
  U[Validated upload] --> S[Local object file + SHA-256]
  S --> Q[Persistent job record]
  Q --> T[PDF text parser / configured image OCR]
  T --> C[Checklist category schema]
  C --> X[Explicit-label field extraction]
  X --> V[Application consistency + duplicate checks]
  V --> D[Version diff + preliminary findings]
  D --> N[In-app notification + evaluator queue]
  D --> R[Preliminary JSON report]
  X -. optional configured endpoint .-> A[AI extraction suggestion]
  A --> H[Human validation required]
```

## Components

- `src/pdf-text.mjs`: extracts PDF `Tj` and `TJ` text operators from uncompressed or Flate streams. It does not claim complete PDF support or resolve page numbers.
- `src/document-pipeline.mjs`: category-specific schemas and explicit-label extraction, optional Tesseract invocation for images, application name consistency checking, and extracted-value comparison across versions.
- `src/ai-extractor.mjs`: optional OpenAI-compatible structured extraction adapter. It is disabled unless URL, key and model are configured. Uploaded text is untrusted; the adapter instructs the model not to follow document instructions. AI values remain unverified suggestions.
- `server.mjs`: persistent job records, background execution in the same process, restart recovery, bounded retries, duplicate SHA-256 checks, in-app notifications, evaluator queue ordering, and preliminary report API.

## Data and status semantics

- `completed_deterministic`: local PDF parsing and label-pattern extraction ran. This is not a statement of authenticity or compliance.
- `completed_ai_suggestion`: the configured provider returned advisory field suggestions; a human must validate them.
- `needs_manual_ocr`: the PDF had no extractable native text or image OCR is unavailable.
- `needs_manual_review`: configured OCR ran but returned no useful text.
- `failed`: configured processing failed. Authorized users may retry while attempts remain.

Extracted values retain their source method and nullable, uncalibrated confidence. Page references are null when the parser cannot establish them. Reports preserve those unknowns rather than inventing citations.

## Not implemented here

No PDF renderer for scanned PDF pages, table reconstruction, trained classifier, official regulation retrieval/RAG, email/SMS, malware scanner, or independent AI accuracy metrics are available. OCR is disabled unless Tesseract is explicitly configured. Compliance rules remain illustrative pending regulatory expert validation.

## Human final-decision stage

The demonstration now includes a separate `decision_maker` role and prioritized final-decision queue. An evaluator recommendation moves a case to `Recommendation recorded`. A decision maker may approve, reject, or return it for clarification only from that state and must provide a reason. Returning sends the application through institutional resubmission and evaluator review again; prior decision records remain in history. Approvals and rejections are human actions. The returned JSON record is explicitly marked as a demonstration, not an official AICTE communication.

Demo sign-in: `decision-maker@example.test`, password `Demo1234!`. The credential is public and must never be reused outside this synthetic local demo.
