# AI integration

All model calls run **on the server** (`src/ai-provider.mjs`). The browser only talks to this app's own API and never sees a key.

## Turning AI on
The AI inside the application needs its own runtime API key; using Claude to write the code does not enable it.

1. Copy `.env.example` to `.env` (or set environment variables).
2. Anthropic Claude: `AICTE_AI_PROVIDER=anthropic`, `ANTHROPIC_API_KEY`, `AICTE_AI_MODEL`. (Calls `POST /v1/messages`; override host with `AICTE_ANTHROPIC_BASE_URL` for a gateway.)
3. OpenAI-compatible (legacy, still supported): `AICTE_AI_PROVIDER=openai-compatible` (or just set `AICTE_AI_BASE_URL`), `AICTE_AI_API_KEY`, `AICTE_AI_MODEL`.
4. Restart. The header chip shows **AI: ready · model**, **AI: not configured**, or **AI: last request failed**. `GET /api/ai/status` returns the same (never the key).

No model name is hard-coded: set one your key can use. If AI is not configured or a call fails, the UI says so; nothing is ever replaced with made-up output. Rule-based checks keep working without AI.

## What uses AI
| Feature | Endpoint | Notes |
|---|---|---|
| Document analysis | automatic after upload (existing job pipeline) | Text sent to model; fields must carry a verbatim quote that is found in the document text or they are discarded. Deterministic label matches always win; disagreements become a finding. |
| Scans / images | same, only if `AICTE_AI_VISION=1` | Sends the file itself. Values are labelled "AI read from image · unverified". PDFs need the Anthropic provider. |
| Compliance checks | `GET /api/applications/:id/ai/analysis` | **No model.** Deterministic comparisons: missing items, unreadable files, name mismatches, duplicate uploads, date problems. |
| Plain-English explanations | `POST …/ai/explain` | Rephrases existing findings only; unknown ids are dropped. |
| Summary / correction guidance | `POST …/ai/summary` | Evaluators/decision-makers get a reviewer briefing; institutions get correction guidance. |
| Assistant Q&A | `POST …/ai/ask` | Answers only from this application's authorised context; citations must resolve to real records. |

There is no AI endpoint that approves, rejects, returns or records anything. The decision workflow is unchanged and role-gated.

## Evidence labels
Every value is tagged: **Deterministic label match**, OCR (Tesseract, when configured), **AI suggestion · quote found in text**, or **AI read from image · unverified**. Confidence numbers are not invented (`null` = not calibrated).

## Cost controls
- Extraction results are cached by file hash + prompt version + provider + model, so identical files are never re-analysed (even in another application). Summaries/explanations/answers are cached per application, role and exact context.
- Input is capped (`AICTE_AI_MAX_INPUT_CHARS`), output is capped, calls time out, a small concurrency limit applies, and each user has a per-10-minute call budget. One short retry only for 429/5xx/network errors.
- `ai_runs` table records task, status, cached flag and token counts (no content) for cost review.

## Security model
- Documents, extracted values and questions are untrusted data. System prompts tell the model never to follow instructions inside them, the model has no tools, and every reply is parsed against a strict schema (allow-listed fields, length caps, verified citations). Output is HTML-escaped in the UI.
- Ownership/role checks are the same as every other endpoint (`owns()`); other institutions' data is never placed in a prompt.
- Minimum data: extraction sends document text only; assistant calls send extracted field values, check/finding text, workflow state and the last few history entries — not raw document text or files (unless vision is enabled).
- **External providers receive whatever is sent to them.** Use synthetic data only unless you have a data-processing agreement and legal sign-off. Provider retention is governed by your agreement with them.
- Wording guard: replies that use authenticity/fraud or approve/reject language get a visible notice. Discrepancies are never classified as fraud; extraction is not proof of authenticity.

## Rules
`rules/compliance-rules.json` is a versioned ruleset (`rulesetId`, `version`, per-rule `ruleVersion`, `source`, `effectiveFrom`). A rule counts as verified only if it has `verified: true` **and** a source and effective date. The shipped rules are demonstration placeholders and are labelled "unverified demo rule" everywhere. Do not add official requirements without expert verification.

## Known limits
- Native-text PDFs and Tesseract OCR remain the deterministic path; there is no PDF page renderer, so page numbers are `null`.
- Prompts are English; answers can still be wrong. Humans must check originals.
- Rate limits and caches are per process / local SQLite (demo scale).
- Existing behaviour kept: the SHA-256 duplicate check compares against uploads in all applications and stores the other upload's id in the finding; consider scoping it before multi-tenant use.
