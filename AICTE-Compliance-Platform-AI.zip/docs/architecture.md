# Architecture and functional scope

## Current demonstration architecture

A single-page HTML/CSS/JavaScript client calls a Node.js HTTP API. Node's built-in SQLite module stores accounts, applications, document metadata, background job state, extracted fields, findings, notifications, reviewer notes and activity events. Uploaded bytes are held under `work/uploads`. The app uses in-memory sessions and public demo identities with password hashes. It is an executable local demonstration, not a production deployment.

```mermaid
flowchart LR
  B[Browser: institution / evaluator] --> H[Node HTTP API]
  H --> D[(SQLite local database)]
  H --> F[Local upload directory]
  H --> W[Checklist + workflow service]
  W --> E[Hash-linked event history]
```

The institution account can manage only its own records. The evaluator can access the synthetic review queue. A separate demo decision-maker identity can approve, reject, or return recommended cases with a required reason. Server-side checks enforce those roles for API actions. The document worker runs as a replaceable in-process queue in this demo; production should move it to a durable background worker. The UI includes an application register, search/status filter, upload/download, extraction status, report, notifications, review queue, findings, analytics and rule notes.

## Production target

Keep a modular monolith initially: React/TypeScript client, FastAPI service, PostgreSQL, encrypted object storage and a separate document-processing worker with a reliable queue. A production identity provider and MFA should replace demo accounts. Each extraction result should contain evidence page, confidence and model/version; uncertain or consequential findings must route to authorized review. All published regulatory rules need source citations, effective dates and independent approval.

## User journeys

- Institution: sign in, create a category-specific draft, upload files to checklist categories, submit, review findings, replace/add evidence, and resubmit.
- Evaluator: sign in, review assigned/available synthetic submissions, return with a reason or record a recommendation. The demo has no final approval action.
- Regulatory administrator: in the future, propose sourced effective-dated rule versions and obtain separate approval before publishing.

## Delivery plan

1. Verify the currently applicable handbook, amendments, categories, roles and workflows with authorized regulatory experts.
2. Replace demo identity, SQLite and disk storage with production identity, PostgreSQL and encrypted object storage.
3. Add malware scanning and asynchronous OCR/classification/extraction; evaluate confidence on properly authorized synthetic/annotated data.
4. Add approved versioned rules, verified deadlines, notifications, escalation, inspection and human decision workflows.
5. Add cited RAG, append-only audit anchoring, security/performance validation, backup/restore exercises and controlled pilot.

Measure baselines from actual operations. Do not infer statutory deadlines or promise assumed improvement percentages.


