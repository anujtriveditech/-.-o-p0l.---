# Unresolved regulatory assumptions

The referenced handbook URL is not proof that the document remains applicable. Experts must verify the current handbook, amendments/corrigenda, academic year, exact clauses, application categories, conditional applicability, forms, fees, inspection triggers, decision authority, appeal routes and deadlines before configuration. All three checklist rows in this demo are placeholders, not official requirements. No statutory SLA is seeded. Unknown rule interpretation must be escalated for expert review. Extraction and document content do not prove authenticity or determine approval.

The checklist now lives in the versioned file `rules/compliance-rules.json`; every rule is `verified: false` until an expert supplies a source reference and effective date.
