# Workflow

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Submitted: Institution submits
  Returned --> Submitted: Institution resubmits
  Submitted --> Returned: Evaluator requests correction
  Submitted --> RecommendationRecorded: Evaluator recommends
  RecommendationRecorded --> Approved: Decision maker approves with reason
  RecommendationRecorded --> Rejected: Decision maker rejects with reason
  RecommendationRecorded --> Returned: Decision maker requests correction
  Approved --> [*]
  Rejected --> [*]
```

The local demo enforces draft → submission → evaluator return/recommendation → human final decision. A returned case can be corrected, resubmitted, evaluated and decided again; decision numbers and audit events preserve each round. Approve, reject and return require a signed-in `decision_maker` role and a reason. The public demo decision-maker credential is only a test role, not proof of actual delegated regulatory authority. The generated JSON is marked non-official.

The workflow remains category-configurable only in a future production release. Do not configure statutory deadlines until they are verified against currently applicable official rules.

Delivery phases: 1) regulatory mapping and role validation; 2) identity, institution registration, forms, uploads and status; 3) OCR/extraction worker with evidence and confidence; 4) versioned rules, deadlines, notifications and resubmission; 5) evaluator, inspections, human decision workflow and audit controls; 6) cited RAG, analytics, security/performance validation and pilot. Measure baselines from actual operating data; do not promise assumed improvements.
