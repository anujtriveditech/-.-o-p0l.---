# AICTE Approval and Compliance Platform — Portable Demo

## Start on Windows

1. Install Node.js 24 or newer on the receiving laptop.
2. Extract this folder somewhere writable, such as Documents.
3. Double-click `start-windows.bat`.
4. The browser opens at http://localhost:4173. Keep the terminal window open while using the app; press Ctrl+C in that window to stop the server.

No npm install or internet connection is needed. The first launch creates `work/demo.sqlite` and `work/uploads` beside the app. These contain saved application data and uploaded documents; keep the folder private and back it up if needed. The distributable does not include your current laptop's database or uploaded files.

If port 4173 is already in use, close the other local instance before starting this one.

## Demo accounts

All accounts use the public synthetic demo password `Demo1234!`:

- Institution: `institution@example.test`
- Evaluator: `evaluator@example.test`
- Final decision-maker: `decision-maker@example.test`

These accounts are for synthetic demonstration data only. The final-decision workflow records a human demo action and produces a decision record explicitly labeled as non-official. It does not connect to AICTE or issue a regulatory approval.

## Other operating systems

Install Node.js 24 or newer, open a terminal in this folder, and run:

```sh
node --experimental-sqlite server.mjs
```

Then open http://localhost:4173.

## What is included

Institution application drafts, PDF/JPEG/PNG upload, deterministic text-PDF extraction, optional Tesseract image OCR, optional configured OpenAI-compatible field suggestions, findings, document version comparison, evaluator queue, human final-decision queue, preliminary JSON reports, notifications, and local SQLite persistence.

OCR and a model provider are not configured in this package by default. See `docs/automation.md` for requirements and truthful processing states. The compliance checklist is illustrative, not an official AICTE rule set. Do not expose the local demo to a public network or use real sensitive records.

## Verification

Run the automated checks from a terminal:

```sh
node --test
```


## AI features (optional)
AI document analysis, plain-English finding explanations, reviewer summaries / institution correction guidance and a Q&A assistant are built in but off until you configure a provider. Copy `.env.example` to `.env`, choose Anthropic Claude or an OpenAI-compatible endpoint, add your own API key and model, and restart. See `docs/ai-integration.md` for setup, data-protection notes (external providers receive the data sent to them), cost controls and limits. AI is advisory only and never approves, rejects or decides.
