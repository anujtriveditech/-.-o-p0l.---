$ErrorActionPreference = 'Stop'
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    throw 'Node.js 24 or newer is required. Install Node.js, then run this launcher again.'
}
$major = [int]((& $node.Source -p 'process.versions.node').Split('.')[0])
if ($major -lt 24) {
    throw "Node.js 24 or newer is required. Detected Node.js $((& $node.Source -p 'process.versions.node'))."
}
$env:PORT = '4173'
$process = Start-Process -FilePath $node.Source -ArgumentList @('--experimental-sqlite', 'server.mjs') -WorkingDirectory $PSScriptRoot -NoNewWindow -PassThru
try {
    $ready = $false
    for ($i = 0; $i -lt 40; $i++) {
        if ($process.HasExited) { throw 'The server stopped before it became ready.' }
        try {
            $null = Invoke-WebRequest -Uri 'http://localhost:4173/api/health' -TimeoutSec 1
            $ready = $true
            break
        } catch { Start-Sleep -Milliseconds 250 }
    }
    if (-not $ready) { throw 'The server did not become ready. Port 4173 may already be in use.' }
    Start-Process 'http://localhost:4173'
    Write-Host 'AICTE demo is running. Keep this window open; press Ctrl+C here to stop it.'
    Wait-Process -Id $process.Id
} catch {
    if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
    throw
}
